import UIKit

print("——————— 1.将不同的对象装进数组里面，并且可以取出来判断 ———————")

protocol Value {
    var str: Any { get set }
    
    func merge(type: String)
} // 定义一个协议

struct str0: Value {
    var str: Any = ("1", 2, true)
    
    func merge(type: String) {
        print(str)
    }
} // 定义一个遵守 Value 协议的结构体

class str1: Value {
    var str: Any = "21"
    
    func merge(type: String) {
        print(str)
    }
} // 定义一个遵守 Value 协议的类

let merge0 = str0()
let merge1 = str1()

let array: [Value] = [merge0, merge1]
// 声明一个遵守协议 Value 的数组，
let array0 = array.first
let array1 = array.last

if array0 is Value {
    print("遵守 Value 类型")
} else {
    print("不遵守 Value 类型")
}

if array1 is Value {
    print("遵守 Value 类型")
} else {
    print("不遵守 Value 类型")
}
// 类型判断

print("——————— 2.代理扩展 ———————")

var Subjects = "作业"

protocol School {
    func homeWork()
}
// 首先定义一个协议，以学校布置作业为例

class mathWork: School{
    func homeWork() {
        Subjects = "数学"
    }
}

class chineseWork: School{
    func homeWork() {
        Subjects = "语文"
    }
}
// 这两个 “类” 实现了 “学校” 的协议，这里表示的是布置不同科目的作业

class Teacher {
    var Student: School // 调用协议，可以看成是学生在老师的带领下遵守学校的规章制度

    init (Student: School) {
        self.Student = Student
    } // 构造函数

    func wirteHomeWork() {
        Student.homeWork()
        print(Subjects, "老师布置了", Subjects, "作业。晚上，学生完成了", Subjects, "作业。")
    } // 通过方法实现 “学生写老师布置的遵守学校规范的作业”
}

// 下面是测试环节
let work0 = Teacher(Student: mathWork())
work0.wirteHomeWork()

let work1 = Teacher(Student: chineseWork())
work1.wirteHomeWork()
